# GitLab CI/CD



## 课程内容

- 为什么要做CI/CD？
- GitLab CI/CD基本功能简介
- GitLabCI 与Jenkins对比分析
- 扩展-如何安装部署GitLab？







